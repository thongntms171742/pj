import React, { useState, useRef } from "react";
import {
  ShoppingCart, MessageCircle, User, Search, Heart, Star, ChevronRight,
  Package, Truck, CheckCircle, Clock, MapPin, LogOut, Send, Minus, Plus,
  Trash2, Tag, Shield, HelpCircle, Edit3, X, Bell, Upload, Sparkles,
  Store, SlidersHorizontal, FileText, Image as ImageIcon, ChevronDown,
  Settings, Check, Percent
} from "lucide-react";

// ── Brand palette ──────────────────────────────────────────────────────────────
const T = "#D27D2D";
const ESPRESSO = "#3A2312";
const COFFEE = "#6F4E37";
const LINEN = "#FAF0E6";
const CARD = "#FFF8F0";
const MUTED = "#E8D5BC";
const SOFT = "#EFE0CC";

type Screen = "login" | "home" | "search" | "cart" | "chat" | "account" | "post";

interface Product {
  id: number; name: string; price: number; seller: string;
  condition: number; size: string; category: string; image: string; liked: boolean;
}
interface Seller {
  id: number; handle: string; name: string; avatar: string;
  rating: number; transactions: number; thumbs: string[];
}
interface CartItem {
  id: number; name: string; price: number; size: string;
  qty: number; image: string; checked: boolean; condition: number;
}
interface CartGroup { seller: string; items: CartItem[]; }

function fmt(n: number) { return n.toLocaleString("vi-VN") + "₫"; }
const ff = { fontFamily: "'Nunito', sans-serif" };
const serif = { fontFamily: "'Playfair Display', serif" };

// ── Static data ────────────────────────────────────────────────────────────────
const ALL_PRODUCTS: Product[] = [
  { id: 1, name: "Áo Linen Trắng Cổ Điển 1994", price: 185000, seller: "minhtu.vintage", condition: 85, size: "M", category: "Áo", image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&h=520&fit=crop&auto=format", liked: false },
  { id: 2, name: "Quần Jean Ống Rộng Thập Niên 90", price: 220000, seller: "saigon.thrift", condition: 90, size: "L", category: "Quần", image: "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=400&h=520&fit=crop&auto=format", liked: true },
  { id: 3, name: "Váy Hoa Retro Pastel Dáng A", price: 160000, seller: "hanoi.preloved", condition: 75, size: "S", category: "Váy", image: "https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?w=400&h=520&fit=crop&auto=format", liked: false },
  { id: 4, name: "Áo Khoác Denim Rửa Cũ 80s", price: 350000, seller: "minhtu.vintage", condition: 80, size: "M", category: "Áo khoác", image: "https://images.unsplash.com/photo-1495105787522-5334e3ffa0ef?w=400&h=520&fit=crop&auto=format", liked: false },
  { id: 5, name: "Blazer Tweed Cổ Điển", price: 420000, seller: "saigon.thrift", condition: 92, size: "M", category: "Áo khoác", image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=400&h=520&fit=crop&auto=format", liked: true },
  { id: 6, name: "Áo Sơ Mi Kẻ Sọc Vintage", price: 130000, seller: "hanoi.preloved", condition: 70, size: "L", category: "Áo", image: "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=400&h=520&fit=crop&auto=format", liked: false },
  { id: 7, name: "Đầm Maxi Bohemian Floral", price: 280000, seller: "vintage.corner", condition: 88, size: "M", category: "Váy", image: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=400&h=520&fit=crop&auto=format", liked: false },
  { id: 8, name: "Áo Phông Band Tee 90s", price: 95000, seller: "minhtu.vintage", condition: 65, size: "L", category: "Áo", image: "https://images.unsplash.com/photo-1509631179647-0177331693ae?w=400&h=520&fit=crop&auto=format", liked: true },
  { id: 9, name: "Quần Culottes Len Vintage", price: 175000, seller: "saigon.thrift", condition: 82, size: "S", category: "Quần", image: "https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=400&h=520&fit=crop&auto=format", liked: false },
  { id: 10, name: "Áo Len Cổ Lọ Cozy", price: 210000, seller: "vintage.corner", condition: 78, size: "M", category: "Áo", image: "https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=400&h=520&fit=crop&auto=format", liked: false },
];

const SELLERS: Seller[] = [
  { id: 1, handle: "minhtu.vintage", name: "Minh Tú Vintage", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&auto=format", rating: 4.9, transactions: 234, thumbs: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=90&h=90&fit=crop", "https://images.unsplash.com/photo-1495105787522-5334e3ffa0ef?w=90&h=90&fit=crop", "https://images.unsplash.com/photo-1509631179647-0177331693ae?w=90&h=90&fit=crop"] },
  { id: 2, handle: "saigon.thrift", name: "Sài Gòn Thrift", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&auto=format", rating: 4.8, transactions: 187, thumbs: ["https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=90&h=90&fit=crop", "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=90&h=90&fit=crop", "https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=90&h=90&fit=crop"] },
  { id: 3, handle: "hanoi.preloved", name: "Hà Nội Pre-loved", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&auto=format", rating: 4.7, transactions: 156, thumbs: ["https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?w=90&h=90&fit=crop", "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=90&h=90&fit=crop", "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=90&h=90&fit=crop"] },
  { id: 4, handle: "vintage.corner", name: "Vintage Corner HCM", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop&auto=format", rating: 4.9, transactions: 312, thumbs: ["https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=90&h=90&fit=crop", "https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=90&h=90&fit=crop", "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=90&h=90&fit=crop"] },
];

const INIT_CART: CartGroup[] = [
  { seller: "minhtu.vintage", items: [
    { id: 1, name: "Áo Linen Trắng Cổ Điển 1994", price: 185000, size: "M", qty: 1, condition: 85, image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=100&h=100&fit=crop&auto=format", checked: true },
    { id: 4, name: "Áo Khoác Denim Rửa Cũ 80s", price: 350000, size: "M", qty: 1, condition: 80, image: "https://images.unsplash.com/photo-1495105787522-5334e3ffa0ef?w=100&h=100&fit=crop&auto=format", checked: true },
  ]},
  { seller: "saigon.thrift", items: [
    { id: 2, name: "Quần Jean Ống Rộng Thập Niên 90", price: 220000, size: "L", qty: 1, condition: 90, image: "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=100&h=100&fit=crop&auto=format", checked: true },
    { id: 5, name: "Blazer Tweed Cổ Điển", price: 420000, size: "M", qty: 1, condition: 92, image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=100&h=100&fit=crop&auto=format", checked: false },
  ]},
];

const CONTACTS = [
  { id: 1, name: "minhtu.vintage", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=80&h=80&fit=crop&auto=format", lastMsg: "Bạn có thể chụp thêm ảnh chi tiết không?", time: "3 phút", unread: 2, product: { name: "Áo Linen Trắng Cổ Điển 1994", price: 185000, image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=80&h=80&fit=crop&auto=format" } },
  { id: 2, name: "saigon.thrift", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80&h=80&fit=crop&auto=format", lastMsg: "Đã xác nhận và đang chuẩn bị hàng", time: "1 giờ", unread: 0, product: { name: "Quần Jean Ống Rộng 90", price: 220000, image: "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=80&h=80&fit=crop&auto=format" } },
  { id: 3, name: "hanoi.preloved", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=80&h=80&fit=crop&auto=format", lastMsg: "Giá có thể thương lượng không ạ?", time: "Hôm qua", unread: 1, product: { name: "Váy Hoa Retro Pastel", price: 160000, image: "https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?w=80&h=80&fit=crop&auto=format" } },
];

const CHAT_MSGS: Record<number, Array<{ id: number; from: "me" | "seller"; text: string; time: string }>> = {
  1: [
    { id: 1, from: "seller", text: "Xin chào bạn! Shop có thể giúp gì nào? 🌿", time: "14:20" },
    { id: 2, from: "me", text: "Mình quan tâm áo linen trắng, còn size M không ạ?", time: "14:21" },
    { id: 3, from: "seller", text: "Vâng bạn ơi, còn đúng 1 cái size M! Hàng đẹp lắm, mới giặt hấp phẳng rồi nè 🧺", time: "14:22" },
    { id: 4, from: "me", text: "Bạn có thể chụp thêm ảnh chi tiết không? Ảnh cổ áo và tay áo ấy", time: "14:23" },
    { id: 5, from: "seller", text: "Được bạn nhé, mình chụp ngay đây! Hàng vintage 1994 nên có vài nét xỉn màu nhẹ, rất đẹp 🧡", time: "14:25" },
    { id: 6, from: "me", text: "Oke không sao, mình thích vintage look đó. Ship tới HCM mất bao lâu?", time: "14:26" },
    { id: 7, from: "seller", text: "Giao Hàng Nhanh 3-5 ngày, phí ship khoảng 30.000₫ bạn nhé. Shop đóng gói cẩn thận 📦", time: "14:28" },
  ],
  2: [
    { id: 1, from: "seller", text: "Cảm ơn bạn đã tin tưởng Sài Gòn Thrift! 💛", time: "10:30" },
    { id: 2, from: "me", text: "Mình vừa đặt quần jean ống rộng, bao giờ giao ạ?", time: "10:31" },
    { id: 3, from: "seller", text: "Đã xác nhận và đang chuẩn bị hàng bạn ơi, sẽ giao trong 24h nhé!", time: "10:45" },
  ],
  3: [
    { id: 1, from: "me", text: "Chào shop! Váy hoa retro còn không ạ?", time: "Hôm qua" },
    { id: 2, from: "seller", text: "Còn bạn ơi! Bạn thích size nào? Shop có S và M", time: "Hôm qua" },
    { id: 3, from: "me", text: "Giá có thể thương lượng không ạ?", time: "Hôm qua" },
  ],
};

// ── Logo ───────────────────────────────────────────────────────────────────────
function ThriftLogo({ size = 48 }: { size?: number }) {
  return (
    <img 
      src="https://i.postimg.cc/44tgtTTG/thrift-logo.png" 
      alt="thrift it! Logo"
      style={{ 
        width: size, 
        height: size, 
        objectFit: "contain"
      }} 
    />
  );
}

// ── Header ─────────────────────────────────────────────────────────────────────
const FILTER_TAGS = ["Tất cả", "Áo", "Quần", "Váy", "Áo khoác", "Phụ kiện", "Độ mới >90%", "Gần đây"];

function Header({ screen, go, cartCount }: { screen: Screen; go: (s: Screen) => void; cartCount: number }) {
  const [activeTag, setActiveTag] = useState("Tất cả");
  const showTags = screen === "home" || screen === "search";

  return (
    <header className="sticky top-0 z-50 w-full" style={{ backgroundColor: COFFEE }}>
      <div className="max-w-[1440px] mx-auto px-8 flex items-center gap-6 h-16">
        {/* Logo */}
        <button onClick={() => go("home")} className="flex items-center gap-3 flex-shrink-0 group">
          <ThriftLogo size={38}  />
          <span className="text-xl font-bold italic" style={{ ...serif, color: LINEN, letterSpacing: "-0.3px" }}>
            thrift it!
          </span>
        </button>

        {/* Search bar */}
        <div className="flex-1 max-w-2xl mx-4">
          <div
            className="flex items-center gap-3 px-4 py-2.5 rounded-xl cursor-text transition-all hover:opacity-90"
            style={{ backgroundColor: "rgba(250,240,230,0.15)", border: "1.5px solid rgba(250,240,230,0.25)" }}
            onClick={() => go("search")}
          >
            <Sparkles size={17} style={{ color: T, flexShrink: 0 }} />
            <span className="flex-1 text-sm" style={{ ...ff, color: "rgba(250,240,230,0.6)" }}>
              Tìm áo vintage, quần jean cổ điển bằng AI...
            </span>
            <button
              onClick={(e) => { e.stopPropagation(); go("search"); }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all hover:opacity-90"
              style={{ backgroundColor: T, color: LINEN, ...ff }}
            >
              <Search size={13} />
              Tìm
            </button>
          </div>
        </div>

        {/* Nav icons */}
        <div className="flex items-center gap-1 flex-shrink-0">
          {[
            { id: "cart" as Screen, icon: ShoppingCart, label: "Giỏ hàng", badge: cartCount },
            { id: "chat" as Screen, icon: MessageCircle, label: "Tin nhắn", badge: 3 },
            { id: "notification" as Screen, icon: Bell, label: "Thông báo", badge: 5 },
            { id: "account" as Screen, icon: User, label: "Tài khoản", badge: 0 },
          ].map(({ id, icon: Icon, label, badge }) => (
            <button
              key={id}
              onClick={() => go(id)}
              className="relative flex flex-col items-center gap-0.5 px-4 py-2 rounded-xl transition-all hover:bg-white/10"
              style={{ color: screen === id ? T : "rgba(250,240,230,0.85)" }}
            >
              <div className="relative">
                <Icon size={20} strokeWidth={screen === id ? 2.5 : 1.8} />
                {badge > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-bold"
                    style={{ backgroundColor: T, color: LINEN, ...ff }}>
                    {badge}
                  </span>
                )}
              </div>
              <span className="text-[10px] font-medium" style={ff}>{label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Filter tags sub-row */}
      {showTags && (
        <div style={{ backgroundColor: "rgba(0,0,0,0.18)", borderTop: "1px solid rgba(255,255,255,0.08)" }}>
          <div className="max-w-[1440px] mx-auto px-8 flex items-center gap-2 py-2.5 overflow-x-auto" style={{ scrollbarWidth: "none" }}>
            <SlidersHorizontal size={14} style={{ color: MUTED, flexShrink: 0 }} />
            <span className="text-xs font-semibold mr-1" style={{ color: MUTED, ...ff, flexShrink: 0 }}>Bộ lọc nhanh:</span>
            {FILTER_TAGS.map((tag) => (
              <button
                key={tag}
                onClick={() => setActiveTag(tag)}
                className="flex-shrink-0 px-3.5 py-1 rounded-full text-xs font-semibold border transition-all hover:opacity-90"
                style={{
                  backgroundColor: activeTag === tag ? T : "rgba(250,240,230,0.12)",
                  color: activeTag === tag ? LINEN : "rgba(250,240,230,0.8)",
                  borderColor: activeTag === tag ? T : "rgba(250,240,230,0.2)",
                  ...ff,
                }}
              >
                {tag}
              </button>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}

// ── Footer ─────────────────────────────────────────────────────────────────────
function Footer({ go }: { go: (s: Screen) => void }) {
  const links = [
    { title: "Về thrift it!", items: ["Giới thiệu", "Blog vintage", "Câu chuyện người dùng", "Tuyển dụng"] },
    { title: "Hỗ trợ người mua", items: ["Hướng dẫn mua hàng", "Chính sách đổi trả", "Thanh toán an toàn", "Theo dõi đơn hàng"] },
    { title: "Hỗ trợ người bán", items: ["Hướng dẫn đăng bán", "Phí & hoa hồng", "Quy tắc cộng đồng", "Trở thành shop uy tín"] },
    { title: "Kết nối với chúng tôi", items: ["Instagram", "TikTok", "Facebook", "Zalo OA"] },
  ];
  return (
    <footer style={{ backgroundColor: ESPRESSO }}>
      <div className="max-w-[1440px] mx-auto px-8 py-12">
        <div className="grid grid-cols-5 gap-10">
          <div className="col-span-1">
            <div className="flex items-center gap-2.5 mb-3">
              <ThriftLogo size={36} light />
              <span className="text-lg font-bold italic" style={{ ...serif, color: LINEN }}>thrift it!</span>
            </div>
            <p className="text-xs leading-relaxed" style={{ color: MUTED, ...ff }}>
              Thị trường C2C thời trang cũ hàng đầu Việt Nam. Mua bán đồ vintage chất lượng, giá tốt.
            </p>
            <button
              onClick={() => go("post")}
              className="mt-4 px-4 py-2 rounded-lg text-xs font-bold transition-all hover:opacity-90"
              style={{ backgroundColor: T, color: LINEN, ...ff }}
            >
              + Đăng bán ngay
            </button>
          </div>
          {links.map((col) => (
            <div key={col.title}>
              <h4 className="text-xs font-bold tracking-widest mb-4" style={{ color: T, ...ff }}>{col.title.toUpperCase()}</h4>
              <ul className="space-y-2.5">
                {col.items.map((item) => (
                  <li key={item}>
                    <a href="#" className="text-xs hover:text-white transition-colors" style={{ color: MUTED, ...ff }}>{item}</a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-10 pt-6 flex items-center justify-between" style={{ borderTop: "1px solid rgba(255,255,255,0.1)" }}>
          <p className="text-xs" style={{ color: MUTED, ...ff }}>© 2024 thrift it! — Nền tảng mua bán đồ vintage Việt Nam</p>
          <div className="flex items-center gap-6">
            {["Điều khoản sử dụng", "Chính sách riêng tư", "Cookie"].map((l) => (
              <a key={l} href="#" className="text-xs hover:text-white transition-colors" style={{ color: MUTED, ...ff }}>{l}</a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}

// ── Login Screen ───────────────────────────────────────────────────────────────
function LoginScreen({ onLogin }: { onLogin: () => void }) {
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");

  return (
    <div className="min-h-screen flex" style={{ backgroundColor: LINEN }}>
      {/* Left: hero image */}
      <div className="flex-1 relative overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?w=900&h=1080&fit=crop&auto=format"
          alt="Vintage clothing collection"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 flex flex-col justify-end p-16"
          style={{ background: "linear-gradient(to top, rgba(58,35,18,0.85) 0%, rgba(58,35,18,0.3) 50%, transparent 100%)" }}>
          <div className="flex items-center gap-3 mb-4">
            <ThriftLogo size={52} light />
            <span className="text-4xl font-bold italic" style={{ ...serif, color: LINEN }}>thrift it!</span>
          </div>
          <h2 className="text-3xl font-bold mb-3" style={{ ...serif, color: LINEN }}>
            Thời trang cũ,<br />giá trị mới 🌿
          </h2>
          <p className="text-base" style={{ color: MUTED, ...ff }}>
            Khám phá hàng ngàn món đồ vintage độc đáo từ<br />các shop uy tín khắp Việt Nam.
          </p>
          <div className="flex items-center gap-6 mt-6">
            {[["12.000+", "Sản phẩm"], ["4.800+", "Người bán"], ["98%", "Hài lòng"]].map(([v, l]) => (
              <div key={l}>
                <div className="text-2xl font-bold" style={{ ...serif, color: T }}>{v}</div>
                <div className="text-xs" style={{ color: MUTED, ...ff }}>{l}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right: login form */}
      <div className="w-[500px] flex-shrink-0 flex items-center justify-center p-12" style={{ backgroundColor: CARD }}>
        <div className="w-full max-w-[380px]">
          {/* Logo mark */}
          <div className="flex flex-col items-center mb-10">
            <ThriftLogo size={60} />
            <h1 className="text-3xl font-bold italic mt-3" style={{ ...serif, color: ESPRESSO }}>thrift it!</h1>
            <p className="text-sm mt-1" style={{ color: COFFEE, ...ff }}>Chào mừng bạn trở lại</p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold mb-1.5" style={{ color: COFFEE, ...ff }}>Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="ban@email.com"
                className="w-full px-4 py-3 rounded-xl text-sm outline-none border-2 transition-all focus:border-opacity-100"
                style={{ backgroundColor: SOFT, border: `2px solid ${MUTED}`, color: ESPRESSO, ...ff }}
              />
            </div>
            <div>
              <div className="flex justify-between mb-1.5">
                <label className="text-xs font-bold" style={{ color: COFFEE, ...ff }}>Mật khẩu</label>
                <a href="#" className="text-xs font-semibold hover:underline" style={{ color: T, ...ff }}>Quên mật khẩu?</a>
              </div>
              <input
                type="password"
                value={pw}
                onChange={(e) => setPw(e.target.value)}
                placeholder="••••••••"
                className="w-full px-4 py-3 rounded-xl text-sm outline-none border-2 transition-all"
                style={{ backgroundColor: SOFT, border: `2px solid ${MUTED}`, color: ESPRESSO, ...ff }}
              />
            </div>

            <button
              onClick={onLogin}
              className="w-full py-3.5 rounded-xl text-base font-bold shadow-lg transition-all hover:opacity-90 active:scale-[0.98] mt-2"
              style={{ backgroundColor: T, color: LINEN, ...ff }}
            >
              Đăng Nhập
            </button>

            <div className="flex items-center gap-3">
              <div className="flex-1 h-px" style={{ backgroundColor: MUTED }} />
              <span className="text-xs" style={{ color: COFFEE, ...ff }}>hoặc</span>
              <div className="flex-1 h-px" style={{ backgroundColor: MUTED }} />
            </div>

            <button className="w-full py-3 rounded-xl text-sm font-semibold border-2 transition-all hover:bg-opacity-80"
              style={{ border: `2px solid ${MUTED}`, color: COFFEE, backgroundColor: "transparent", ...ff }}>
              Đăng ký tài khoản mới
            </button>
          </div>

          <p className="text-xs text-center mt-6" style={{ color: COFFEE, ...ff }}>
            Bằng cách đăng nhập, bạn đồng ý với{" "}
            <a href="#" className="underline" style={{ color: T }}>Điều khoản sử dụng</a>
          </p>
        </div>
      </div>
    </div>
  );
}

// ── Product Card ───────────────────────────────────────────────────────────────
function ProductCard({ product, onLike, go }: { product: Product; onLike: (id: number) => void; go: (s: Screen) => void }) {
  const condColor = product.condition >= 90 ? "#27AE60" : product.condition >= 75 ? T : "#E67E22";
  return (
    <div
      className="rounded-2xl overflow-hidden shadow-sm hover:shadow-lg transition-all duration-200 cursor-pointer group"
      style={{ backgroundColor: CARD, border: `1px solid ${MUTED}` }}
    >
      <div className="relative overflow-hidden" style={{ paddingBottom: "130%" }}>
        <img
          src={product.image}
          alt={product.name}
          className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <button
          onClick={(e) => { e.stopPropagation(); onLike(product.id); }}
          className="absolute top-2.5 right-2.5 w-8 h-8 rounded-full flex items-center justify-center shadow-md transition-all hover:scale-110"
          style={{ backgroundColor: "rgba(255,248,240,0.9)" }}
        >
          <Heart size={15} fill={product.liked ? T : "none"} stroke={product.liked ? T : COFFEE} />
        </button>
        <div className="absolute bottom-2.5 left-2.5 flex items-center gap-1.5">
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ backgroundColor: condColor, color: LINEN, ...ff }}>
            {product.condition}%
          </span>
          <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full" style={{ backgroundColor: "rgba(58,35,18,0.75)", color: LINEN, ...ff }}>
            {product.size}
          </span>
        </div>
      </div>
      <div className="p-3">
        <p className="text-sm font-semibold truncate leading-snug" style={{ color: ESPRESSO, ...ff }}>{product.name}</p>
        <p className="text-xs mt-0.5" style={{ color: COFFEE, ...ff }}>@{product.seller}</p>
        <p className="text-base font-bold mt-1.5" style={{ ...serif, color: T }}>{fmt(product.price)}</p>
        <div className="flex gap-2 mt-3 pt-2" style={{ borderTop: `1px dashed ${MUTED}55` }}>
          <button 
            onClick={(e) => { e.stopPropagation(); go("account"); }}
            className="flex-1 py-2 rounded-xl text-[11px] font-bold transition-all hover:opacity-90"
            style={{ backgroundColor: T, color: LINEN }}
          >
            Mua ngay
          </button>
          <button 
            onClick={(e) => { e.stopPropagation(); go("cart"); }}
            className="p-2 rounded-xl transition-all hover:bg-opacity-80 flex items-center justify-center"
            style={{ border: `1.5px solid ${T}`, color: T, backgroundColor: "transparent" }}
          >
            <ShoppingCart size={14} />
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Seller Card ────────────────────────────────────────────────────────────────
function SellerCard({ seller }: { seller: Seller }) {
  return (
    <div
      className="rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-200 cursor-pointer"
      style={{ backgroundColor: CARD, border: `1px solid ${MUTED}` }}
    >
      <div className="p-5">
        <div className="flex items-center gap-3 mb-3">
          <img src={seller.avatar} alt={seller.name} className="w-12 h-12 rounded-full object-cover border-2" style={{ borderColor: T }} />
          <div>
            <p className="text-sm font-bold" style={{ color: ESPRESSO, ...ff }}>{seller.name}</p>
            <p className="text-xs" style={{ color: COFFEE, ...ff }}>@{seller.handle}</p>
          </div>
        </div>
        <div className="flex items-center gap-2 mb-3">
          <div className="flex">
            {[1,2,3,4,5].map((i) => (
              <Star key={i} size={12} fill={i <= Math.floor(seller.rating) ? T : "none"} stroke={T} />
            ))}
          </div>
          <span className="text-xs font-bold" style={{ color: T, ...ff }}>{seller.rating}</span>
          <span className="text-xs" style={{ color: COFFEE, ...ff }}>· {seller.transactions} giao dịch</span>
        </div>
        <div className="grid grid-cols-3 gap-1.5">
          {seller.thumbs.map((src, i) => (
            <div key={i} className="rounded-lg overflow-hidden" style={{ paddingBottom: "100%", position: "relative", backgroundColor: MUTED }}>
              <img src={src} alt="" className="absolute inset-0 w-full h-full object-cover" />
            </div>
          ))}
        </div>
      </div>
      <div className="px-5 pb-4">
        <button className="w-full py-2 rounded-xl text-xs font-bold border transition-all hover:opacity-80"
          style={{ border: `1.5px solid ${T}`, color: T, ...ff }}>
          Xem cửa hàng
        </button>
      </div>
    </div>
  );
}

// ── Home Screen ────────────────────────────────────────────────────────────────
function HomeScreen({ go, products, onLike }: { go: (s: Screen) => void; products: Product[]; onLike: (id: number) => void }) {
  return (
    <div style={{ backgroundColor: LINEN }}>
      {/* Hero banner */}
      <div className="relative w-full overflow-hidden" style={{ height: "340px" }}>
        <img
          src="https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?w=1440&h=400&fit=crop&auto=format"
          alt="Vintage collection"
          className="w-full h-full object-cover object-top"
        />
        <div className="absolute inset-0 flex items-center" style={{ background: "linear-gradient(90deg, rgba(58,35,18,0.8) 0%, rgba(58,35,18,0.3) 60%, transparent 100%)" }}>
          <div className="max-w-[1440px] mx-auto w-full px-8">
            <p className="text-sm font-bold mb-2 uppercase tracking-widest" style={{ color: T, ...ff }}>✦ Bộ sưu tập mới tuần này</p>
            <h2 className="text-5xl font-bold leading-tight mb-4" style={{ ...serif, color: LINEN }}>
              Mặc vintage,<br />sống có tâm 🌿
            </h2>
            <p className="text-base mb-6" style={{ color: MUTED, ...ff }}>Mua và bán đồ cũ — góp phần giảm thiểu lãng phí thời trang</p>
            <div className="flex gap-3">
              <button onClick={() => go("search")}
                className="px-6 py-3 rounded-xl font-bold text-sm transition-all hover:opacity-90 shadow-lg"
                style={{ backgroundColor: T, color: LINEN, ...ff }}>
                Khám phá ngay
              </button>
              <button onClick={() => go("post")}
                className="px-6 py-3 rounded-xl font-bold text-sm border-2 transition-all hover:bg-white/10"
                style={{ border: `2px solid ${LINEN}`, color: LINEN, ...ff }}>
                + Đăng bán cá nhân
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-[1440px] mx-auto px-8 py-12">
        {/* Trusted Sellers */}
        <div className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold" style={{ ...serif, color: ESPRESSO }}>Gợi ý Shop Uy Tín</h2>
              <p className="text-sm mt-0.5" style={{ color: COFFEE, ...ff }}>Được đánh giá cao từ cộng đồng thrift it!</p>
            </div>
            <button className="text-sm font-semibold flex items-center gap-1 hover:underline" style={{ color: T, ...ff }}>
              Xem tất cả <ChevronRight size={15} />
            </button>
          </div>
          <div className="grid grid-cols-4 gap-5">
            {SELLERS.map((s) => <SellerCard key={s.id} seller={s} />)}
          </div>
        </div>

        {/* New Listings */}
        <div>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold" style={{ ...serif, color: ESPRESSO }}>
                Mới Đăng <span className="text-lg font-normal italic ml-2" style={{ color: COFFEE }}>Recently Listed</span>
              </h2>
              <p className="text-sm mt-0.5" style={{ color: COFFEE, ...ff }}>Những món mới nhất từ cộng đồng thrift it!</p>
            </div>
            <button onClick={() => go("search")} className="text-sm font-semibold flex items-center gap-1 hover:underline" style={{ color: T, ...ff }}>
              Xem tất cả <ChevronRight size={15} />
            </button>
          </div>
          <div className="grid grid-cols-5 gap-5">
           {products.map((p) => <ProductCard go={go} key={p.id} product={p} onLike={onLike} />)}
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Filter Sidebar ─────────────────────────────────────────────────────────────
function FilterSidebar() {
  const [cats, setCats] = useState<string[]>([]);
  const [minP, setMinP] = useState("");
  const [maxP, setMaxP] = useState("");
  const [sizes, setSizes] = useState<string[]>([]);
  const [cond, setCond] = useState(50);
  const [ai, setAi] = useState(false);

  const toggleCat = (c: string) => setCats((p) => p.includes(c) ? p.filter((x) => x !== c) : [...p, c]);
  const toggleSize = (s: string) => setSizes((p) => p.includes(s) ? p.filter((x) => x !== s) : [...p, s]);

  const Row = ({ label, children }: { label: string; children: React.ReactNode }) => (
    <div className="py-5" style={{ borderBottom: `1px solid ${MUTED}` }}>
      <h4 className="text-xs font-bold uppercase tracking-wider mb-3" style={{ color: COFFEE, ...ff }}>{label}</h4>
      {children}
    </div>
  );

  return (
    <aside className="w-64 flex-shrink-0 rounded-2xl overflow-hidden shadow-sm" style={{ backgroundColor: CARD, border: `1px solid ${MUTED}`, alignSelf: "start", position: "sticky", top: "128px" }}>
      <div className="px-5 pt-5">
        <div className="flex items-center justify-between mb-1">
          <h3 className="text-base font-bold" style={{ ...serif, color: ESPRESSO }}>Bộ lọc nâng cao</h3>
          <button className="text-xs font-semibold hover:underline" style={{ color: T, ...ff }}>Xóa tất cả</button>
        </div>
        <p className="text-xs" style={{ color: COFFEE, ...ff }}>Tìm đúng món bạn cần</p>
      </div>
      <div className="px-5">
        <Row label="Danh mục">
          <div className="space-y-2">
            {["Áo", "Quần", "Váy", "Áo khoác", "Phụ kiện"].map((c) => (
              <label key={c} className="flex items-center gap-2.5 cursor-pointer group">
                <div
                  onClick={() => toggleCat(c)}
                  className="w-4 h-4 rounded border-2 flex items-center justify-center transition-all"
                  style={{ borderColor: cats.includes(c) ? T : MUTED, backgroundColor: cats.includes(c) ? T : "transparent" }}
                >
                  {cats.includes(c) && <Check size={10} style={{ color: LINEN }} />}
                </div>
                <span className="text-sm" style={{ color: ESPRESSO, ...ff }}>{c}</span>
              </label>
            ))}
          </div>
        </Row>

        <Row label="Khoảng giá (₫)">
          <div className="flex items-center gap-2">
            <input value={minP} onChange={(e) => setMinP(e.target.value)} placeholder="Từ" className="flex-1 px-3 py-2 rounded-lg text-xs outline-none border" style={{ border: `1.5px solid ${MUTED}`, color: ESPRESSO, backgroundColor: SOFT, ...ff }} />
            <span className="text-xs" style={{ color: COFFEE }}>—</span>
            <input value={maxP} onChange={(e) => setMaxP(e.target.value)} placeholder="Đến" className="flex-1 px-3 py-2 rounded-lg text-xs outline-none border" style={{ border: `1.5px solid ${MUTED}`, color: ESPRESSO, backgroundColor: SOFT, ...ff }} />
          </div>
          <div className="flex gap-1.5 mt-2 flex-wrap">
            {["< 100k", "100-300k", "300-500k", "> 500k"].map((r) => (
              <button key={r} className="text-[10px] px-2.5 py-1 rounded-full border transition-all hover:opacity-80" style={{ border: `1px solid ${MUTED}`, color: COFFEE, ...ff }}>{r}</button>
            ))}
          </div>
        </Row>

        <Row label="Kích cỡ">
          <div className="flex flex-wrap gap-1.5">
            {["XS", "S", "M", "L", "XL", "XXL", "XXXL"].map((s) => (
              <button
                key={s}
                onClick={() => toggleSize(s)}
                className="w-10 h-8 rounded-lg text-xs font-bold border transition-all"
                style={{ border: `1.5px solid ${sizes.includes(s) ? T : MUTED}`, backgroundColor: sizes.includes(s) ? T : "transparent", color: sizes.includes(s) ? LINEN : COFFEE, ...ff }}
              >{s}</button>
            ))}
          </div>
        </Row>

        <Row label={`Độ mới tối thiểu: ${cond}%`}>
          <input type="range" min={30} max={100} value={cond} onChange={(e) => setCond(Number(e.target.value))}
            className="w-full h-2 rounded-full cursor-pointer" style={{ accentColor: T }} />
          <div className="flex justify-between mt-1">
            <span className="text-[10px]" style={{ color: COFFEE, ...ff }}>30%</span>
            <span className="text-[10px]" style={{ color: COFFEE, ...ff }}>100%</span>
          </div>
        </Row>

        <div className="py-5" style={{ borderBottom: `1px solid ${MUTED}` }}>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold" style={{ color: ESPRESSO, ...ff }}>✨ Gợi ý từ AI</p>
              <p className="text-xs mt-0.5" style={{ color: COFFEE, ...ff }}>Để AI tìm món phù hợp phong cách bạn</p>
            </div>
            <button
              onClick={() => setAi(!ai)}
              className="w-12 h-6 rounded-full transition-all relative"
              style={{ backgroundColor: ai ? T : MUTED }}
            >
              <span className="absolute top-0.5 w-5 h-5 rounded-full transition-all shadow-sm"
                style={{ backgroundColor: "white", left: ai ? "calc(100% - 22px)" : "2px" }} />
            </button>
          </div>
        </div>

        <div className="py-5">
          <button className="w-full py-2.5 rounded-xl text-sm font-bold transition-all hover:opacity-90"
            style={{ backgroundColor: T, color: LINEN, ...ff }}>
            Áp dụng bộ lọc
          </button>
        </div>
      </div>
    </aside>
  );
}

// ── Search Screen ──────────────────────────────────────────────────────────────
function SearchScreen({ products, onLike }: { products: Product[]; onLike: (id: number) => void }) {
  const [query, setQuery] = useState("áo vintage");
  const [sort, setSort] = useState("Mới nhất");

  return (
    <div className="min-h-screen" style={{ backgroundColor: LINEN }}>
      <div className="max-w-[1440px] mx-auto px-8 py-8">
        {/* Search summary */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-bold" style={{ ...serif, color: ESPRESSO }}>
              Kết quả cho <span style={{ color: T }}>"áo vintage"</span>
            </h2>
            <p className="text-sm mt-0.5" style={{ color: COFFEE, ...ff }}>{products.length} sản phẩm tìm thấy · Được gợi ý bởi AI ✨</p>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-sm" style={{ color: COFFEE, ...ff }}>Sắp xếp theo:</span>
            <div className="relative">
              <select
                value={sort}
                onChange={(e) => setSort(e.target.value)}
                className="appearance-none pl-3 pr-8 py-2 rounded-xl text-sm outline-none border cursor-pointer"
                style={{ border: `1.5px solid ${MUTED}`, color: ESPRESSO, backgroundColor: CARD, ...ff }}
              >
                {["Mới nhất", "Giá tăng dần", "Giá giảm dần", "Độ mới cao nhất", "Nổi bật nhất"].map((o) => (
                  <option key={o}>{o}</option>
                ))}
              </select>
              <ChevronDown size={14} className="absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color: COFFEE }} />
            </div>
          </div>
        </div>

        <div className="flex gap-7">
          <FilterSidebar />
          <div className="flex-1">
            {/* AI suggestion banner */}
            <div className="flex items-center gap-3 px-4 py-3 rounded-xl mb-6" style={{ backgroundColor: `${T}18`, border: `1.5px solid ${T}44` }}>
              <Sparkles size={18} style={{ color: T }} />
              <p className="text-sm" style={{ color: ESPRESSO, ...ff }}>
                <strong>AI gợi ý:</strong> Dựa trên lịch sử tìm kiếm, bạn có thể thích các kiểu áo linen cổ điển và áo sơ mi vintage oversize.
              </p>
            </div>

            <div className="grid grid-cols-4 gap-5">
              {products.map((p) => <ProductCard key={p.id} product={p} onLike={onLike} />)}
            </div>

            {/* Load more */}
            <div className="flex justify-center mt-10">
              <button className="px-8 py-3 rounded-xl text-sm font-bold border-2 transition-all hover:opacity-80"
                style={{ border: `2px solid ${T}`, color: T, ...ff }}>
                Tải thêm sản phẩm
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Cart Screen ────────────────────────────────────────────────────────────────
function CartScreen({ go }: { go: (s: Screen) => void }) {
  const [cart, setCart] = useState<CartGroup[]>(INIT_CART);
  const [promo, setPromo] = useState("");
  const [promoApplied, setPromoApplied] = useState(false);
  const [promoError, setPromoError] = useState(false);

  const allItems = cart.flatMap((g) => g.items);
  const checkedItems = allItems.filter((i) => i.checked);
  const allChecked = allItems.length > 0 && allItems.every((i) => i.checked);
  const someChecked = allItems.some((i) => i.checked);

  const subtotal = checkedItems.reduce((s, i) => s + i.price * i.qty, 0);
  const discount = promoApplied ? Math.round(subtotal * 0.1) : 0;
  const ship = checkedItems.length > 0 ? 30000 : 0;
  const total = subtotal - discount + ship;

  const toggleAll = () => {
    const next = !allChecked;
    setCart((p) => p.map((g) => ({ ...g, items: g.items.map((i) => ({ ...i, checked: next })) })));
  };
  const toggleGroup = (seller: string) => {
    const group = cart.find((g) => g.seller === seller);
    if (!group) return;
    const allGroupChecked = group.items.every((i) => i.checked);
    setCart((p) => p.map((g) => g.seller !== seller ? g : { ...g, items: g.items.map((i) => ({ ...i, checked: !allGroupChecked })) }));
  };
  const toggleItem = (seller: string, id: number) =>
    setCart((p) => p.map((g) => g.seller !== seller ? g : { ...g, items: g.items.map((i) => i.id === id ? { ...i, checked: !i.checked } : i) }));
  const adjustQty = (seller: string, id: number, d: number) =>
    setCart((p) => p.map((g) => g.seller !== seller ? g : { ...g, items: g.items.map((i) => i.id === id ? { ...i, qty: Math.max(1, i.qty + d) } : i) }));
  const removeItem = (seller: string, id: number) =>
    setCart((p) => p.map((g) => ({ ...g, items: g.items.filter((i) => !(g.seller === seller && i.id === id)) })).filter((g) => g.items.length > 0));
  const removeChecked = () =>
    setCart((p) => p.map((g) => ({ ...g, items: g.items.filter((i) => !i.checked) })).filter((g) => g.items.length > 0));

  const applyPromo = () => {
    if (!promo.trim()) return;
    if (promo.toUpperCase() === "THRIFT10" || promo.toUpperCase() === "VINTAGE") {
      setPromoApplied(true);
      setPromoError(false);
    } else {
      setPromoError(true);
      setPromoApplied(false);
    }
  };

  // Inline checkbox button for reuse
  const Checkbox = ({ checked, onClick }: { checked: boolean; onClick: () => void }) => (
    <button
      onClick={onClick}
      className="flex-shrink-0 flex items-center justify-center rounded transition-all"
      style={{
        width: 20, height: 20,
        border: `2px solid ${checked ? T : MUTED}`,
        backgroundColor: checked ? T : "transparent",
      }}
    >
      {checked && <Check size={11} strokeWidth={3} style={{ color: LINEN }} />}
    </button>
  );

  return (
    <div style={{ backgroundColor: LINEN, minHeight: "100vh" }}>
      {/* Page title bar */}
      <div style={{ backgroundColor: COFFEE, borderBottom: `2px solid rgba(0,0,0,0.15)` }}>
        <div className="max-w-[1440px] mx-auto px-8 py-4 flex items-center gap-3">
          <ShoppingCart size={22} style={{ color: LINEN }} />
          <h1 className="text-xl font-bold italic" style={{ ...serif, color: LINEN }}>
            Giỏ hàng của tôi
          </h1>
          <span className="text-sm px-3 py-0.5 rounded-full ml-1" style={{ backgroundColor: "rgba(255,255,255,0.18)", color: LINEN, ...ff }}>
            {allItems.length} sản phẩm
          </span>
        </div>
      </div>

      <div className="max-w-[1440px] mx-auto px-8 py-8">
        {allItems.length === 0 ? (
          /* Empty state */
          <div className="flex flex-col items-center justify-center py-28 gap-5">
            <div className="w-24 h-24 rounded-full flex items-center justify-center" style={{ backgroundColor: MUTED }}>
              <ShoppingCart size={44} style={{ color: COFFEE }} strokeWidth={1.5} />
            </div>
            <div className="text-center">
              <p className="text-xl font-bold mb-1" style={{ ...serif, color: ESPRESSO }}>Giỏ hàng trống</p>
              <p className="text-sm" style={{ color: COFFEE, ...ff }}>Hãy thêm vài món vintage vào giỏ nhé!</p>
            </div>
            <button className="px-8 py-3 rounded-xl font-bold text-sm transition-all hover:opacity-90 shadow-md"
              style={{ backgroundColor: T, color: LINEN, ...ff }}>
              Tiếp tục mua sắm
            </button>
          </div>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 360px", gap: "28px", alignItems: "start" }}>

            {/* ── LEFT COLUMN ── */}
            <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>

              {/* Select-all toolbar */}
              <div
                className="flex items-center gap-4 px-5 py-3 rounded-2xl"
                style={{ backgroundColor: CARD, border: `1px solid ${MUTED}` }}
              >
                <Checkbox checked={allChecked} onClick={toggleAll} />
                <span className="text-sm font-semibold" style={{ color: ESPRESSO, ...ff }}>
                  Chọn tất cả ({allItems.length} sản phẩm)
                </span>
                {someChecked && (
                  <button
                    onClick={removeChecked}
                    className="ml-auto text-xs font-semibold flex items-center gap-1 px-3 py-1.5 rounded-lg transition-all hover:opacity-80"
                    style={{ color: "#C0392B", backgroundColor: "#FDEDEC", ...ff }}
                  >
                    <Trash2 size={12} /> Xóa đã chọn ({checkedItems.length})
                  </button>
                )}
              </div>

              {/* Seller groups */}
              {cart.map((group) => {
                const groupChecked = group.items.every((i) => i.checked);
                const groupTotal = group.items.filter((i) => i.checked).reduce((s, i) => s + i.price * i.qty, 0);
                return (
                  <div
                    key={group.seller}
                    className="rounded-2xl overflow-hidden"
                    style={{ backgroundColor: CARD, border: `1px solid ${MUTED}`, boxShadow: "0 2px 8px rgba(58,35,18,0.06)" }}
                  >
                    {/* Seller header row */}
                    <div
                      className="flex items-center gap-3 px-5 py-3"
                      style={{ backgroundColor: SOFT, borderBottom: `1px solid ${MUTED}` }}
                    >
                      <Checkbox checked={groupChecked} onClick={() => toggleGroup(group.seller)} />
                      <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0"
                        style={{ backgroundColor: COFFEE, color: LINEN }}>
                        {group.seller.charAt(0).toUpperCase()}
                      </div>
                      <div className="flex-1 min-w-0">
                        <span className="text-sm font-bold" style={{ color: ESPRESSO, ...ff }}>@{group.seller}</span>
                        <span className="ml-2 text-xs px-2 py-0.5 rounded-full" style={{ backgroundColor: `${T}22`, color: T, ...ff }}>
                          ⭐ Shop uy tín
                        </span>
                      </div>
                      <span className="text-xs font-semibold" style={{ color: COFFEE, ...ff }}>
                        {group.items.length} món · {fmt(groupTotal)}
                      </span>
                    </div>

                    {/* Items */}
                    {group.items.map((item, idx) => (
                      <div
                        key={item.id}
                        className="flex items-center gap-4 px-5 py-4"
                        style={{
                          borderBottom: idx < group.items.length - 1 ? `1px solid ${MUTED}55` : "none",
                          backgroundColor: item.checked ? `${T}06` : CARD,
                          transition: "background-color 0.15s",
                        }}
                      >
                        <Checkbox checked={item.checked} onClick={() => toggleItem(group.seller, item.id)} />

                        {/* Product image */}
                        <div className="relative flex-shrink-0">
                          <img
                            src={item.image}
                            alt={item.name}
                            style={{ width: 88, height: 88, objectFit: "cover", borderRadius: 12, border: `1px solid ${MUTED}` }}
                          />
                          <span
                            className="absolute bottom-1.5 left-1.5 text-[9px] font-bold px-1.5 py-0.5 rounded-full"
                            style={{ backgroundColor: ESPRESSO + "dd", color: LINEN, ...ff }}
                          >
                            {item.condition}%
                          </span>
                        </div>

                        {/* Product info */}
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <p className="text-sm font-bold leading-snug" style={{ color: ESPRESSO, ...ff }}>{item.name}</p>
                          <div className="flex items-center gap-2 mt-1.5">
                            <span className="text-xs px-2.5 py-0.5 rounded-full font-medium" style={{ backgroundColor: SOFT, color: COFFEE, border: `1px solid ${MUTED}`, ...ff }}>
                              Size {item.size}
                            </span>
                            <span className="text-xs px-2.5 py-0.5 rounded-full font-medium" style={{ backgroundColor: SOFT, color: COFFEE, border: `1px solid ${MUTED}`, ...ff }}>
                              Độ mới {item.condition}%
                            </span>
                          </div>
                          <p className="text-xs mt-2" style={{ color: COFFEE, ...ff }}>
                            Đơn giá: <span style={{ color: ESPRESSO, fontWeight: 600 }}>{fmt(item.price)}</span>
                          </p>
                        </div>

                        {/* Quantity controls */}
                        <div className="flex items-center gap-0 rounded-xl overflow-hidden flex-shrink-0"
                          style={{ border: `1.5px solid ${MUTED}` }}>
                          <button
                            onClick={() => adjustQty(group.seller, item.id, -1)}
                            className="flex items-center justify-center transition-all hover:opacity-70"
                            style={{ width: 34, height: 34, backgroundColor: SOFT, color: COFFEE }}
                          >
                            <Minus size={13} />
                          </button>
                          <span
                            className="flex items-center justify-center text-sm font-bold"
                            style={{ width: 38, height: 34, color: ESPRESSO, backgroundColor: CARD, borderLeft: `1.5px solid ${MUTED}`, borderRight: `1.5px solid ${MUTED}`, ...ff }}
                          >
                            {item.qty}
                          </span>
                          <button
                            onClick={() => adjustQty(group.seller, item.id, 1)}
                            className="flex items-center justify-center transition-all hover:opacity-90"
                            style={{ width: 34, height: 34, backgroundColor: T, color: LINEN }}
                          >
                            <Plus size={13} />
                          </button>
                        </div>

                        {/* Line total */}
                        <div className="text-right flex-shrink-0" style={{ minWidth: 110 }}>
                          <p className="text-base font-bold" style={{ ...serif, color: T }}>{fmt(item.price * item.qty)}</p>
                          {item.qty > 1 && (
                            <p className="text-xs mt-0.5" style={{ color: COFFEE, ...ff }}>{fmt(item.price)} × {item.qty}</p>
                          )}
                        </div>

                        {/* Remove */}
                        <button
                          onClick={() => removeItem(group.seller, item.id)}
                          className="flex-shrink-0 p-2 rounded-xl transition-all hover:opacity-80 ml-1"
                          style={{ backgroundColor: "#FDEDEC" }}
                        >
                          <Trash2 size={15} style={{ color: "#C0392B" }} />
                        </button>
                      </div>
                    ))}
                  </div>
                );
              })}

              {/* Suggested upsell hint */}
              <div
                className="flex items-center gap-3 px-5 py-3.5 rounded-2xl"
                style={{ backgroundColor: `${T}0F`, border: `1.5px dashed ${T}55` }}
              >
                <Sparkles size={18} style={{ color: T, flexShrink: 0 }} />
                <p className="text-sm" style={{ color: ESPRESSO, ...ff }}>
                  <strong>Gợi ý từ AI:</strong> Bạn thường mua cùng với "Áo Linen" — thử xem thêm{" "}
                  <span className="font-bold underline cursor-pointer" style={{ color: T }}>Quần linen ống rộng vintage</span> nhé!
                </p>
              </div>
            </div>

            {/* ── RIGHT COLUMN: Summary panel ── */}
            <div style={{ display: "flex", flexDirection: "column", gap: "16px", position: "sticky", top: "128px" }}>

              {/* Promo code card */}
              <div
                className="rounded-2xl overflow-hidden"
                style={{ backgroundColor: CARD, border: `1px solid ${MUTED}`, boxShadow: "0 2px 8px rgba(58,35,18,0.06)" }}
              >
                <div className="px-5 py-3.5 flex items-center gap-2" style={{ backgroundColor: SOFT, borderBottom: `1px solid ${MUTED}` }}>
                  <Percent size={15} style={{ color: T }} />
                  <span className="text-sm font-bold" style={{ color: ESPRESSO, ...ff }}>Mã giảm giá</span>
                </div>
                <div className="p-4">
                  <div className="flex gap-2">
                    <input
                      value={promo}
                      onChange={(e) => { setPromo(e.target.value); setPromoError(false); }}
                      onKeyDown={(e) => e.key === "Enter" && applyPromo()}
                      placeholder="Nhập mã giảm giá..."
                      className="flex-1 px-4 py-2.5 rounded-xl text-sm outline-none border-2 transition-all"
                      style={{
                        backgroundColor: SOFT,
                        border: `2px solid ${promoError ? "#C0392B" : promoApplied ? "#27AE60" : MUTED}`,
                        color: ESPRESSO,
                        ...ff,
                      }}
                    />
                    <button
                      onClick={applyPromo}
                      className="px-4 py-2.5 rounded-xl text-sm font-bold flex-shrink-0 transition-all hover:opacity-90 active:scale-[0.97]"
                      style={{
                        backgroundColor: promoApplied ? "#27AE6022" : T,
                        color: promoApplied ? "#27AE60" : LINEN,
                        border: `2px solid ${promoApplied ? "#27AE60" : T}`,
                        ...ff,
                      }}
                    >
                      {promoApplied ? "✓ Đã dùng" : "Áp dụng"}
                    </button>
                  </div>
                  {promoError && (
                    <p className="text-xs mt-2" style={{ color: "#C0392B", ...ff }}>
                      ✗ Mã không hợp lệ hoặc đã hết hạn. Thử mã <strong>THRIFT10</strong>
                    </p>
                  )}
                  {promoApplied && (
                    <p className="text-xs mt-2 font-semibold" style={{ color: "#27AE60", ...ff }}>
                      ✓ Đã áp dụng mã — giảm 10% tạm tính!
                    </p>
                  )}
                  <div className="flex gap-2 mt-3 flex-wrap">
                    {["THRIFT10", "VINTAGE", "FREESHIP"].map((code) => (
                      <button
                        key={code}
                        onClick={() => { setPromo(code); setPromoError(false); }}
                        className="text-[10px] font-bold px-2.5 py-1 rounded-full border transition-all hover:opacity-80"
                        style={{ border: `1px dashed ${T}`, color: T, backgroundColor: `${T}0F`, ...ff }}
                      >
                        {code}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Order summary card */}
              <div
                className="rounded-2xl overflow-hidden"
                style={{ backgroundColor: CARD, border: `1px solid ${MUTED}`, boxShadow: "0 2px 8px rgba(58,35,18,0.06)" }}
              >
                <div className="px-5 py-3.5 flex items-center gap-2" style={{ backgroundColor: SOFT, borderBottom: `1px solid ${MUTED}` }}>
                  <Tag size={15} style={{ color: T }} />
                  <span className="text-sm font-bold" style={{ color: ESPRESSO, ...ff }}>Tóm tắt đơn hàng</span>
                </div>

                <div className="px-5 pt-4 pb-2 space-y-3">
                  {/* Line items */}
                  {cart.map((g) => {
                    const groupCheckedItems = g.items.filter((i) => i.checked);
                    if (groupCheckedItems.length === 0) return null;
                    return (
                      <div key={g.seller}>
                        <p className="text-[11px] font-bold uppercase tracking-wide mb-1.5" style={{ color: COFFEE, ...ff }}>
                          @{g.seller}
                        </p>
                        {groupCheckedItems.map((item) => (
                          <div key={item.id} className="flex justify-between items-start mb-1">
                            <span className="text-xs leading-snug pr-2 flex-1" style={{ color: ESPRESSO, ...ff }}>
                              {item.name} <span style={{ color: COFFEE }}>×{item.qty}</span>
                            </span>
                            <span className="text-xs font-semibold flex-shrink-0" style={{ color: ESPRESSO, ...ff }}>
                              {fmt(item.price * item.qty)}
                            </span>
                          </div>
                        ))}
                      </div>
                    );
                  })}
                </div>

                {/* Totals */}
                <div className="px-5 pb-5 pt-2" style={{ borderTop: `1px solid ${MUTED}` }}>
                  <div className="space-y-2.5 pt-3">
                    <div className="flex justify-between text-sm">
                      <span style={{ color: COFFEE, ...ff }}>Tạm tính ({checkedItems.length} sản phẩm)</span>
                      <span style={{ color: ESPRESSO, ...ff }}>{fmt(subtotal)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span style={{ color: COFFEE, ...ff }}>Phí vận chuyển</span>
                      <span style={{ color: ESPRESSO, ...ff }}>{checkedItems.length > 0 ? fmt(ship) : "—"}</span>
                    </div>
                    {promoApplied && (
                      <div className="flex justify-between text-sm font-semibold">
                        <span style={{ color: "#27AE60", ...ff }}>Giảm giá (10%)</span>
                        <span style={{ color: "#27AE60", ...ff }}>−{fmt(discount)}</span>
                      </div>
                    )}
                  </div>

                  <div
                    className="flex justify-between items-center mt-4 pt-4"
                    style={{ borderTop: `2px solid ${MUTED}` }}
                  >
                    <span className="font-bold text-base" style={{ color: ESPRESSO, ...ff }}>Tổng thanh toán</span>
                    <span className="text-2xl font-bold" style={{ ...serif, color: T }}>{fmt(total)}</span>
                  </div>

                  {/* CTA Button */}
                  <button
                    className="w-full mt-4 py-4 rounded-2xl font-bold text-base shadow-lg transition-all hover:opacity-90 active:scale-[0.98]"
                    style={{
                      backgroundColor: checkedItems.length === 0 ? MUTED : T,
                      color: checkedItems.length === 0 ? COFFEE : LINEN,
                      cursor: checkedItems.length === 0 ? "not-allowed" : "pointer",
                      ...ff,
                    }}
                   onClick={() => go("account")} // <── THÊM DÒNG NÀY VÀO ĐÂY
                disabled={checkedItems.length === 0}
              >
                {checkedItems.length === 0
                  ? "Chọn sản phẩm để mua"
                  : `Mua Hàng (${checkedItems.length} món)`}
              </button>

                  <div className="flex items-center justify-center gap-1.5 mt-3">
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                      <path d="M6 1L7.5 4.5H11L8.5 6.5L9.5 10L6 8L2.5 10L3.5 6.5L1 4.5H4.5L6 1Z" fill={COFFEE} />
                    </svg>
                    <p className="text-[11px]" style={{ color: COFFEE, ...ff }}>
                      🔒 Thanh toán bảo mật · Đổi trả trong 7 ngày
                    </p>
                  </div>
                </div>
              </div>

              {/* Trust badges */}
              <div
                className="rounded-2xl px-4 py-3 grid grid-cols-3 gap-2"
                style={{ backgroundColor: CARD, border: `1px solid ${MUTED}` }}
              >
                {[
                  { icon: "🛡️", label: "Bảo vệ người mua" },
                  { icon: "🔄", label: "Đổi trả dễ dàng" },
                  { icon: "⚡", label: "Giao hàng nhanh" },
                ].map((b) => (
                  <div key={b.label} className="flex flex-col items-center gap-1 py-1">
                    <span className="text-lg">{b.icon}</span>
                    <span className="text-[10px] text-center font-semibold leading-tight" style={{ color: COFFEE, ...ff }}>{b.label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Chat Screen ────────────────────────────────────────────────────────────────
function ChatScreen() {
  const [active, setActive] = useState(1);
  const [msgs, setMsgs] = useState(CHAT_MSGS);
  const [input, setInput] = useState("");
  const [search, setSearch] = useState("");
  const contact = CONTACTS.find((c) => c.id === active)!;
  const conversation = msgs[active] || [];

  const sendMsg = () => {
    if (!input.trim()) return;
    setMsgs((p) => ({ ...p, [active]: [...(p[active] || []), { id: Date.now(), from: "me", text: input.trim(), time: "Vừa xong" }] }));
    setInput("");
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: LINEN }}>
      <div className="max-w-[1440px] mx-auto px-8 py-6">
        <h1 className="text-2xl font-bold mb-4" style={{ ...serif, color: ESPRESSO }}>Tin nhắn</h1>
        <div className="rounded-2xl overflow-hidden shadow-sm flex" style={{ height: "calc(100vh - 200px)", border: `1px solid ${MUTED}` }}>
          {/* Contact list */}
          <div className="w-80 flex-shrink-0 flex flex-col" style={{ borderRight: `1px solid ${MUTED}`, backgroundColor: CARD }}>
            <div className="p-4" style={{ borderBottom: `1px solid ${MUTED}` }}>
              <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl" style={{ backgroundColor: SOFT, border: `1px solid ${MUTED}` }}>
                <Search size={14} style={{ color: COFFEE }} />
                <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Tìm kiếm..." className="flex-1 bg-transparent text-sm outline-none" style={{ color: ESPRESSO, ...ff }} />
              </div>
            </div>
            <div className="flex-1 overflow-y-auto">
              {CONTACTS.filter((c) => c.name.includes(search)).map((c, i) => (
                <div key={c.id}>
                  {i > 0 && <div className="mx-4 h-px" style={{ backgroundColor: MUTED + "55" }} />}
                  <button
                    onClick={() => setActive(c.id)}
                    className="w-full flex items-start gap-3 px-4 py-3.5 text-left transition-all hover:opacity-90"
                    style={{ backgroundColor: active === c.id ? SOFT : "transparent" }}
                  >
                    <div className="relative flex-shrink-0">
                      <img src={c.avatar} alt={c.name} className="w-11 h-11 rounded-full object-cover" />
                      <span className="absolute bottom-0.5 right-0.5 w-3 h-3 rounded-full border-2" style={{ backgroundColor: "#27AE60", borderColor: CARD }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-bold truncate" style={{ color: ESPRESSO, ...ff }}>@{c.name}</p>
                        <p className="text-[10px] flex-shrink-0 ml-2" style={{ color: COFFEE, ...ff }}>{c.time}</p>
                      </div>
                      <p className="text-xs truncate mt-0.5" style={{ color: COFFEE, ...ff }}>{c.lastMsg}</p>
                    </div>
                    {c.unread > 0 && (
                      <span className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold flex-shrink-0 ml-1"
                        style={{ backgroundColor: T, color: LINEN, ...ff }}>{c.unread}</span>
                    )}
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Chat window */}
          <div className="flex-1 flex flex-col" style={{ backgroundColor: LINEN }}>
            {/* Chat header */}
            <div className="flex items-center gap-3 px-5 py-3.5 flex-shrink-0" style={{ borderBottom: `1px solid ${MUTED}`, backgroundColor: CARD }}>
              <img src={contact.avatar} alt="" className="w-9 h-9 rounded-full object-cover" />
              <div className="flex-1">
                <p className="text-sm font-bold" style={{ color: ESPRESSO, ...ff }}>@{contact.name}</p>
                <p className="text-xs" style={{ color: "#27AE60", ...ff }}>● Đang hoạt động</p>
              </div>
              {/* Product overlay */}
              <div className="flex items-center gap-2.5 px-3 py-2 rounded-xl" style={{ backgroundColor: SOFT, border: `1px solid ${MUTED}` }}>
                <img src={contact.product.image} alt="" className="w-10 h-10 rounded-lg object-cover" />
                <div>
                  <p className="text-xs font-semibold max-w-[140px] truncate" style={{ color: ESPRESSO, ...ff }}>{contact.product.name}</p>
                  <p className="text-xs font-bold" style={{ color: T, ...serif }}>{fmt(contact.product.price)}</p>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded-full" style={{ backgroundColor: T + "22", color: T, ...ff }}>Đang hỏi</span>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto px-6 py-5 flex flex-col gap-3">
              <div className="text-center">
                <span className="text-[10px] px-3 py-1 rounded-full" style={{ backgroundColor: MUTED, color: COFFEE, ...ff }}>Hôm nay</span>
              </div>
              {conversation.map((m) => (
                <div key={m.id} className={`flex ${m.from === "me" ? "justify-end" : "justify-start"} gap-2.5`}>
                  {m.from === "seller" && <img src={contact.avatar} alt="" className="w-7 h-7 rounded-full object-cover self-end flex-shrink-0" />}
                  <div className="max-w-[60%]">
                    <div
                      className="px-4 py-2.5 text-sm leading-relaxed"
                      style={{
                        backgroundColor: m.from === "me" ? T : CARD,
                        color: m.from === "me" ? LINEN : ESPRESSO,
                        borderRadius: m.from === "me" ? "18px 18px 4px 18px" : "18px 18px 18px 4px",
                        border: m.from === "seller" ? `1px solid ${MUTED}` : "none",
                        ...ff,
                      }}
                    >{m.text}</div>
                    <p className="text-[9px] mt-1 px-1" style={{ color: COFFEE + "99", textAlign: m.from === "me" ? "right" : "left", ...ff }}>{m.time}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Input */}
            <div className="flex items-center gap-3 px-5 py-3.5 flex-shrink-0" style={{ borderTop: `1px solid ${MUTED}`, backgroundColor: CARD }}>
              <button className="p-2.5 rounded-xl transition-all hover:bg-gray-100" style={{ border: `1px solid ${MUTED}` }}>
                <ImageIcon size={18} style={{ color: COFFEE }} />
              </button>
              <div className="flex-1 flex items-center gap-2 px-4 py-2.5 rounded-xl" style={{ backgroundColor: SOFT, border: `1.5px solid ${MUTED}` }}>
                <input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && sendMsg()}
                  placeholder="Nhắn tin..."
                  className="flex-1 bg-transparent text-sm outline-none"
                  style={{ color: ESPRESSO, ...ff }}
                />
              </div>
              <button
                onClick={sendMsg}
                className="p-2.5 rounded-xl flex items-center justify-center transition-all hover:opacity-90"
                style={{ backgroundColor: T }}
              >
                <Send size={17} style={{ color: LINEN }} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Account Screen ─────────────────────────────────────────────────────────────
// ── Account Screen ─────────────────────────────────────────────────────────────
function AccountScreen({ go, onLogout, products = ALL_PRODUCTS }: { go: (s: Screen) => void; onLogout: () => void; products?: Product[] }) {
  const [orderTab, setOrderTab] = useState<"pending" | "shipping" | "delivering" | "review">("pending");

  const orderTabs = [
    { id: "pending" as const, label: "Chờ thanh toán", icon: Clock, count: 1, color: "#E8A838" },
    { id: "shipping" as const, label: "Vận chuyển", icon: Package, count: 2, color: T },
    { id: "delivering" as const, label: "Đang giao", icon: Truck, count: 1, color: "#2980B9" },
    { id: "review" as const, label: "Đánh giá", icon: Star, count: 3, color: "#27AE60" },
  ];

  const sampleOrders: Record<string, Array<{ id: string; item: string; price: number; seller: string; image: string; status: string }>> = {
    pending: [{ id: "ORD-20240891", item: "Blazer Tweed Cổ Điển", price: 420000, seller: "saigon.thrift", image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=100&h=100&fit=crop&auto=format", status: "Chờ thanh toán" }],
    shipping: [
      { id: "ORD-20240876", item: "Quần Jean Ống Rộng 90", price: 220000, seller: "saigon.thrift", image: "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=100&h=100&fit=crop&auto=format", status: "Đang đóng gói" },
      { id: "ORD-20240865", item: "Váy Hoa Retro Pastel", price: 160000, seller: "hanoi.preloved", image: "https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?w=100&h=100&fit=crop&auto=format", status: "Chờ lấy hàng" },
    ],
    delivering: [{ id: "ORD-20240855", item: "Áo Linen Trắng 1994", price: 185000, seller: "minhtu.vintage", image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=100&h=100&fit=crop&auto=format", status: "Đang giao - GHN" }],
    review: [
      { id: "ORD-20240820", item: "Áo Phông Band Tee 90s", price: 95000, seller: "minhtu.vintage", image: "https://images.unsplash.com/photo-1509631179647-0177331693ae?w=100&h=100&fit=crop&auto=format", status: "Đã giao — chờ đánh giá" },
      { id: "ORD-20240810", item: "Áo Len Cổ Lọ Cozy", price: 210000, seller: "vintage.corner", image: "https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=100&h=100&fit=crop&auto=format", status: "Đã giao — chờ đánh giá" },
      { id: "ORD-20240800", item: "Áo Khoác Denim Rửa Cũ", price: 350000, seller: "minhtu.vintage", image: "https://images.unsplash.com/photo-1495105787522-5334e3ffa0ef?w=100&h=100&fit=crop&auto=format", status: "Đã giao — chờ đánh giá" },
    ],
  };

  const settingsMenu = [
    { icon: Edit3, label: "Hồ sơ cá nhân", sub: "Nguyễn Thanh Linh" },
    { icon: MapPin, label: "Địa chỉ nhận hàng", sub: "2 địa chỉ đã lưu" },
    { icon: Bell, label: "Thông báo", sub: "Đang bật" },
    { icon: Shield, label: "Bảo mật tài khoản", sub: "" },
    { icon: HelpCircle, label: "Trung tâm hỗ trợ", sub: "" },
  ];

  return (
    <div className="min-h-screen" style={{ backgroundColor: LINEN }}>
      {/* Profile header */}
      <div style={{ background: `linear-gradient(135deg, ${ESPRESSO} 0%, ${COFFEE} 100%)` }}>
        <div className="max-w-[1440px] mx-auto px-8 py-8 flex items-center gap-6">
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=160&h=160&fit=crop&auto=format"
              alt="Avatar"
              className="w-24 h-24 rounded-full object-cover border-4 shadow-lg"
              style={{ borderColor: T }}
            />
            <button className="absolute bottom-0 right-0 w-8 h-8 rounded-full flex items-center justify-center shadow-md" style={{ backgroundColor: T }}>
              <Edit3 size={13} style={{ color: LINEN }} />
            </button>
          </div>
          <div>
            <h2 className="text-2xl font-bold" style={{ ...serif, color: LINEN }}>Nguyễn Thanh Linh</h2>
            <p className="text-sm mt-0.5" style={{ color: MUTED, ...ff }}>linh.nguyen@gmail.com</p>
            <div className="flex items-center gap-5 mt-3">
              <div className="flex items-center gap-1.5">
                <div className="flex">{[1,2,3,4,5].map((i) => <Star key={i} size={13} fill={T} stroke="none" />)}</div>
                <span className="text-sm font-bold" style={{ color: T, ...ff }}>4.9</span>
              </div>
              <div className="h-4 w-px" style={{ backgroundColor: MUTED + "66" }} />
              <span className="text-sm" style={{ color: MUTED, ...ff }}>34 giao dịch</span>
              <div className="h-4 w-px" style={{ backgroundColor: MUTED + "66" }} />
              <span className="text-sm px-2.5 py-0.5 rounded-full" style={{ backgroundColor: T + "33", color: T, ...ff }}>Shop uy tín ✓</span>
            </div>
          </div>
          <div className="ml-auto">
            <button
              onClick={() => go("post")}
              className="flex items-center gap-2.5 px-5 py-3 rounded-xl font-bold text-sm shadow-lg transition-all hover:opacity-90"
              style={{ backgroundColor: T, color: LINEN, ...ff }}
            >
              <Store size={17} />
              Đăng bán cá nhân (C2C)
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-[1440px] mx-auto px-8 py-8">
        <div className="grid grid-cols-[280px_1fr] gap-8">
          {/* Left: Settings sidebar */}
          <div className="space-y-5 self-start sticky top-36">
            <div className="rounded-2xl overflow-hidden shadow-sm" style={{ backgroundColor: CARD, border: `1px solid ${MUTED}` }}>
              <div className="px-5 py-4" style={{ borderBottom: `1px solid ${MUTED}`, backgroundColor: SOFT }}>
                <h3 className="text-sm font-bold" style={{ color: ESPRESSO, ...ff }}>Cài đặt tài khoản</h3>
              </div>
              {settingsMenu.map((item, i) => (
                <div key={item.label}>
                  {i > 0 && <div className="mx-5 h-px" style={{ backgroundColor: MUTED + "55" }} />}
                  <button className="w-full flex items-center gap-3 px-5 py-3.5 text-left transition-all hover:opacity-80">
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: SOFT }}>
                      <item.icon size={16} style={{ color: COFFEE }} />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-semibold" style={{ color: ESPRESSO, ...ff }}>{item.label}</p>
                      {item.sub && <p className="text-xs mt-0.5" style={{ color: COFFEE, ...ff }}>{item.sub}</p>}
                    </div>
                    <ChevronRight size={15} style={{ color: MUTED }} />
                  </button>
                </div>
              ))}
              <div className="mx-5 h-px" style={{ backgroundColor: MUTED + "55" }} />
              <button
                onClick={onLogout}
                className="w-full flex items-center gap-3 px-5 py-3.5 transition-all hover:opacity-80"
              >
                <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ backgroundColor: "#FDEDEC" }}>
                  <LogOut size={16} style={{ color: "#E74C3C" }} />
                </div>
                <span className="text-sm font-semibold" style={{ color: "#E74C3C", ...ff }}>Đăng xuất</span>
              </button>
            </div>

            {/* C2C promo card */}
            <div className="rounded-2xl p-5" style={{ background: `linear-gradient(135deg, ${COFFEE} 0%, ${ESPRESSO} 100%)` }}>
              <p className="text-sm font-bold mb-1" style={{ color: LINEN, ...ff }}>🛍 Bán đồ cũ của bạn!</p>
              <p className="text-xs mb-3" style={{ color: MUTED, ...ff }}>Tủ đồ đầy mà không mặc? Hãy thrift it!</p>
              <button onClick={() => go("post")} className="w-full py-2 rounded-xl text-xs font-bold transition-all hover:opacity-90"
                style={{ backgroundColor: T, color: LINEN, ...ff }}>
                + Đăng bán ngay
              </button>
            </div>
          </div>

          {/* Right: Orders & Management */}
          <div className="space-y-8">
            <div>
              <div className="flex items-center justify-between mb-5">
                <h2 className="text-xl font-bold" style={{ ...serif, color: ESPRESSO }}>Đơn mua của tôi</h2>
              </div>

              {/* Tab bar */}
              <div className="grid grid-cols-4 gap-3 mb-6">
                {orderTabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setOrderTab(tab.id)}
                    className="flex flex-col items-center gap-2 py-4 rounded-2xl transition-all hover:shadow-md"
                    style={{
                      backgroundColor: orderTab === tab.id ? tab.color + "18" : CARD,
                      border: `2px solid ${orderTab === tab.id ? tab.color : MUTED}`,
                    }}
                  >
                    <div className="relative">
                      <tab.icon size={26} style={{ color: tab.color }} strokeWidth={1.8} />
                      {tab.count > 0 && (
                        <span className="absolute -top-2 -right-2 w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold"
                          style={{ backgroundColor: tab.color, color: LINEN, ...ff }}>
                          {tab.count}
                        </span>
                      )}
                    </div>
                    <span className="text-xs font-semibold text-center leading-tight" style={{ color: orderTab === tab.id ? tab.color : COFFEE, ...ff }}>
                      {tab.label}
                    </span>
                  </button>
                ))}
              </div>

              {/* Orders list */}
              <div className="space-y-3">
                {(sampleOrders[orderTab] || []).map((order) => (
                  <div key={order.id} className="flex items-center gap-4 p-4 rounded-2xl shadow-sm" style={{ backgroundColor: CARD, border: `1px solid ${MUTED}` }}>
                    <img src={order.image} alt={order.item} className="w-20 h-20 rounded-xl object-cover flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold" style={{ color: ESPRESSO, ...ff }}>{order.item}</p>
                      <p className="text-xs mt-0.5" style={{ color: COFFEE, ...ff }}>@{order.seller} · #{order.id}</p>
                      <span className="inline-block text-xs px-2.5 py-0.5 rounded-full mt-2"
                        style={{ backgroundColor: SOFT, color: COFFEE, ...ff }}>
                        {order.status}
                      </span>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <p className="text-base font-bold" style={{ ...serif, color: T }}>{fmt(order.price)}</p>
                      <button className="mt-2 text-xs px-3 py-1.5 rounded-lg font-semibold transition-all hover:opacity-80"
                        style={{ backgroundColor: T, color: LINEN, ...ff }}>
                        {orderTab === "review" ? "Đánh giá" : "Xem chi tiết"}
                      </button>
                    </div>
                  </div>
                ))}
                {(sampleOrders[orderTab] || []).length === 0 && (
                  <div className="py-16 flex flex-col items-center gap-3">
                    <Package size={48} style={{ color: MUTED }} />
                    <p className="text-base" style={{ color: COFFEE, ...ff }}>Chưa có đơn hàng nào</p>
                  </div>
                )}
              </div>
            </div>

            {/* 📦 Khu vực Quản lý đăng bán tích hợp theo flow yêu cầu */}
            <div className="pt-4" style={{ borderTop: `2px dashed ${MUTED}` }}>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold flex items-center gap-2" style={{ ...serif, color: ESPRESSO }}>
                  📦 Quản lý đăng bán
                </h2>
                <span className="text-xs font-semibold px-3 py-1 rounded-full" style={{ backgroundColor: SOFT, color: COFFEE, ...ff }}>
                  2 sản phẩm đang quản lý
                </span>
              </div>
              
              <div className="space-y-3">
                {/* Item 1 */}
                <div className="flex gap-4 p-4 rounded-2xl shadow-sm items-center transition-all hover:shadow-md" style={{ backgroundColor: CARD, border: `1px solid ${MUTED}` }}>
                  <img src="https://images.unsplash.com/photo-1495105787522-5334e3ffa0ef?w=150" alt="" className="w-16 h-16 rounded-xl object-cover flex-shrink-0 border" style={{ borderColor: MUTED }} />
                  <div className="flex-1 min-w-0">
                    <h4 className="text-sm font-bold truncate" style={{ color: ESPRESSO, ...ff }}>Áo Khoác Denim Rửa Cũ 80s</h4>
                    <div className="flex items-center gap-3 mt-1 text-xs" style={{ color: COFFEE, ...ff }}>
                      <span>Giá: <strong style={{ color: T }}>350.000₫</strong></span>
                      <span>•</span>
                      <span>Số lượng còn: <strong>1 cái</strong></span>
                    </div>
                    <span className="inline-block text-[10px] font-bold px-2 py-0.5 rounded-full mt-2 bg-green-50 text-green-600 border border-green-200">
                      ● Đang bán online
                    </span>
                  </div>
                  <div className="flex gap-2 flex-shrink-0">
                    <button className="px-3 py-1.5 text-xs rounded-xl border border-gray-300 font-semibold transition-all hover:bg-gray-50" style={{ color: COFFEE, ...ff }}>Sửa</button>
                    <button className="px-3 py-1.5 text-xs rounded-xl bg-red-50 border border-red-200 font-semibold text-red-600 transition-all hover:bg-red-100" style={{ ...ff }}>Xóa</button>
                  </div>
                </div>

                {/* Item 2 */}
                <div className="flex gap-4 p-4 rounded-2xl shadow-sm items-center opacity-80 transition-all hover:shadow-md" style={{ backgroundColor: CARD, border: `1px solid ${MUTED}` }}>
                  <img src="https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=150" alt="" className="w-16 h-16 rounded-xl object-cover flex-shrink-0 border" style={{ borderColor: MUTED }} />
                  <div className="flex-1 min-w-0">
                    <h4 className="text-sm font-bold truncate" style={{ color: ESPRESSO, ...ff }}>Quần Jean Ống Rộng Thập Niên 90</h4>
                    <div className="flex items-center gap-3 mt-1 text-xs" style={{ color: COFFEE, ...ff }}>
                      <span>Giá: <strong style={{ color: T }}>220.000₫</strong></span>
                      <span>•</span>
                      <span>Số lượng còn: <strong>2 cái</strong></span>
                    </div>
                    <span className="inline-block text-[10px] font-bold px-2 py-0.5 rounded-full mt-2 bg-amber-50 text-amber-600 border border-amber-200">
                      ⏳ Đang chờ duyệt bài
                    </span>
                  </div>
                  <div className="flex gap-2 flex-shrink-0">
                    <button className="px-3 py-1.5 text-xs rounded-xl border border-gray-300 font-semibold transition-all hover:bg-gray-50" style={{ color: COFFEE, ...ff }}>Sửa</button>
                    <button className="px-3 py-1.5 text-xs rounded-xl bg-red-50 border border-red-200 font-semibold text-red-600 transition-all hover:bg-red-100" style={{ ...ff }}>Xóa</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
// ── Post Listing Screen ────────────────────────────────────────────────────────
function PostScreen({ go }: { go: (s: Screen) => void }) {
  const [dragging, setDragging] = useState(false);
  const [photoCount, setPhotoCount] = useState(0);
  const [name, setName] = useState("");
  const [desc, setDesc] = useState("");
  const [price, setPrice] = useState("");
  const [size, setSize] = useState("M");
  const [condition, setCondition] = useState(80);
  const [category, setCategory] = useState("Áo");

  const condLabel = condition >= 95 ? "Như mới" : condition >= 85 ? "Rất tốt" : condition >= 70 ? "Tốt" : condition >= 55 ? "Khá" : "Trung bình";

  const previewImages = [
    "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=120&h=120&fit=crop&auto=format",
    "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=120&h=120&fit=crop&auto=format",
  ];

  return (
    <div className="min-h-screen" style={{ backgroundColor: LINEN }}>
      {/* Page header */}
      <div style={{ backgroundColor: COFFEE }}>
        <div className="max-w-[1440px] mx-auto px-8 py-5 flex items-center gap-4">
          <button
            onClick={() => go("account")}
            className="flex items-center gap-2 text-sm font-semibold transition-all hover:opacity-80"
            style={{ color: LINEN, ...ff }}
          >
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
              <path d="M11 4L6 9L11 14" stroke={LINEN} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Quay lại
          </button>
          <div className="h-5 w-px" style={{ backgroundColor: LINEN + "44" }} />
          <h1 className="text-xl font-bold italic" style={{ ...serif, color: LINEN }}>Đăng bán cá nhân (C2C)</h1>
          <div className="ml-auto flex items-center gap-2">
            <span className="text-xs px-3 py-1.5 rounded-full" style={{ backgroundColor: "rgba(250,240,230,0.15)", color: LINEN, ...ff }}>
              Bước 1/2 — Thông tin sản phẩm
            </span>
          </div>
        </div>
      </div>

      <div className="max-w-[1440px] mx-auto px-8 py-8">
        <div className="grid grid-cols-[1fr_440px] gap-8">
          {/* Left: Photo upload */}
          <div>
            <h2 className="text-xl font-bold mb-2" style={{ ...serif, color: ESPRESSO }}>Ảnh sản phẩm</h2>
            <p className="text-sm mb-5" style={{ color: COFFEE, ...ff }}>Tối đa 6 ảnh · JPG, PNG · Tối đa 10MB/ảnh</p>

            {/* Drag-drop zone */}
            <div
              onDragOver={(e: React.DragEvent<HTMLDivElement>) => { e.preventDefault(); setDragging(true); }}
              onDragLeave={() => setDragging(false)}
              onDrop={(e: React.DragEvent<HTMLDivElement>) => { e.preventDefault(); setDragging(false); setPhotoCount((p) => Math.min(p + 1, 6)); }}
              className="w-full rounded-2xl border-2 border-dashed flex flex-col items-center justify-center transition-all cursor-pointer"
              style={{
                height: "260px",
                borderColor: dragging ? T : MUTED,
                backgroundColor: dragging ? T + "08" : SOFT,
              }}
              onClick={() => setPhotoCount((p) => Math.min(p + 1, 6))}
            >
              <div className="w-16 h-16 rounded-full flex items-center justify-center mb-4" style={{ backgroundColor: dragging ? T + "22" : MUTED }}>
                <Upload size={28} style={{ color: dragging ? T : COFFEE }} />
              </div>
              <p className="text-base font-semibold" style={{ color: dragging ? T : ESPRESSO, ...ff }}>
                {dragging ? "Thả ảnh vào đây!" : "Kéo thả ảnh hoặc nhấn để chọn"}
              </p>
              <p className="text-sm mt-1" style={{ color: COFFEE, ...ff }}>Ảnh đầu tiên sẽ là ảnh bìa sản phẩm</p>
            </div>

            {/* Uploaded preview grid */}
            {photoCount > 0 && (
              <div className="mt-4">
                <p className="text-xs font-semibold mb-3" style={{ color: COFFEE, ...ff }}>Ảnh đã tải lên ({photoCount}/6)</p>
                <div className="grid grid-cols-6 gap-2">
                  {Array.from({ length: photoCount }).map((_, i) => (
                    <div key={i} className="relative rounded-xl overflow-hidden group" style={{ paddingBottom: "100%", backgroundColor: MUTED }}>
                      <img
                        src={previewImages[i % previewImages.length]}
                        alt=""
                        className="absolute inset-0 w-full h-full object-cover"
                      />
                      {i === 0 && (
                        <span className="absolute bottom-1 left-0 right-0 text-center text-[9px] font-bold py-0.5"
                          style={{ backgroundColor: T + "cc", color: LINEN, ...ff }}>Ảnh bìa</span>
                      )}
                      <button
                        onClick={() => setPhotoCount((p) => p - 1)}
                        className="absolute top-1 right-1 w-5 h-5 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                        style={{ backgroundColor: "rgba(58,35,18,0.7)" }}
                      >
                        <X size={10} style={{ color: LINEN }} />
                      </button>
                    </div>
                  ))}
                  {photoCount < 6 && (
                    <button
                      onClick={() => setPhotoCount((p) => Math.min(p + 1, 6))}
                      className="rounded-xl flex items-center justify-center border-2 border-dashed transition-all hover:opacity-80"
                      style={{ paddingBottom: "100%", position: "relative", borderColor: MUTED, backgroundColor: SOFT }}
                    >
                      <Plus size={20} style={{ color: COFFEE, position: "absolute", top: "50%", left: "50%", transform: "translate(-50%,-50%)" }} />
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Tips */}
            <div className="mt-6 p-4 rounded-xl" style={{ backgroundColor: T + "12", border: `1.5px solid ${T}33` }}>
              <p className="text-sm font-semibold mb-2" style={{ color: ESPRESSO, ...ff }}>💡 Mẹo chụp ảnh bán nhanh</p>
              <ul className="space-y-1.5">
                {[
                  "Chụp dưới ánh sáng tự nhiên để màu sắc thật nhất",
                  "Chụp nhiều góc: trước, sau, cổ, tay áo, chi tiết",
                  "Đặt hàng phẳng hoặc mặc trên người mannequin",
                  "Ảnh rõ nét và không bị mờ sẽ bán nhanh gấp 3 lần",
                ].map((t) => (
                  <li key={t} className="flex items-start gap-1.5 text-xs" style={{ color: COFFEE, ...ff }}>
                    <span style={{ color: T, flexShrink: 0 }}>✓</span> {t}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Right: Form */}
          <div className="rounded-2xl overflow-hidden shadow-sm self-start sticky top-36" style={{ backgroundColor: CARD, border: `1px solid ${MUTED}` }}>
            <div className="px-6 py-4" style={{ borderBottom: `1px solid ${MUTED}`, backgroundColor: SOFT }}>
              <h3 className="text-base font-bold" style={{ ...serif, color: ESPRESSO }}>Thông tin sản phẩm</h3>
            </div>
            <div className="px-6 py-5 space-y-5">
              {/* Name */}
              <div>
                <label className="text-xs font-bold block mb-1.5" style={{ color: COFFEE, ...ff }}>Tên sản phẩm *</label>
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="VD: Áo linen vintage trắng năm 1994..."
                  className="w-full px-4 py-3 rounded-xl text-sm outline-none border-2 transition-all"
                  style={{ backgroundColor: SOFT, border: `2px solid ${MUTED}`, color: ESPRESSO, ...ff }}
                />
              </div>

              {/* Category */}
              <div>
                <label className="text-xs font-bold block mb-1.5" style={{ color: COFFEE, ...ff }}>Danh mục *</label>
                <div className="flex gap-2 flex-wrap">
                  {["Áo", "Quần", "Váy", "Áo khoác", "Phụ kiện"].map((c) => (
                    <button
                      key={c}
                      onClick={() => setCategory(c)}
                      className="px-3.5 py-1.5 rounded-full text-xs font-semibold border transition-all"
                      style={{ backgroundColor: category === c ? T : "transparent", color: category === c ? LINEN : COFFEE, borderColor: category === c ? T : MUTED, ...ff }}
                    >{c}</button>
                  ))}
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="text-xs font-bold block mb-1.5" style={{ color: COFFEE, ...ff }}>Mô tả chi tiết</label>
                <textarea
                  value={desc}
                  onChange={(e) => setDesc(e.target.value)}
                  placeholder="Chất liệu, nguồn gốc, lý do bán, tình trạng thực tế, hướng dẫn giặt..."
                  rows={4}
                  className="w-full px-4 py-3 rounded-xl text-sm outline-none border-2 resize-none transition-all"
                  style={{ backgroundColor: SOFT, border: `2px solid ${MUTED}`, color: ESPRESSO, ...ff }}
                />
              </div>

              {/* Price & Size grid */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold block mb-1.5" style={{ color: COFFEE, ...ff }}>Giá bán (₫) *</label>
                  <div className="relative">
                    <input
                      type="number"
                      value={price}
                      onChange={(e) => setPrice(e.target.value)}
                      placeholder="150000"
                      className="w-full px-4 py-3 rounded-xl text-sm outline-none border-2 transition-all"
                      style={{ backgroundColor: SOFT, border: `2px solid ${MUTED}`, color: ESPRESSO, ...ff }}
                    />
                    {price && (
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold" style={{ color: T, ...ff }}>
                        {fmt(Number(price))}
                      </span>
                    )}
                  </div>
                </div>
                <div>
                  <label className="text-xs font-bold block mb-1.5" style={{ color: COFFEE, ...ff }}>Kích cỡ (Size)</label>
                  <div className="flex gap-1.5 flex-wrap">
                    {["XS","S","M","L","XL","XXL"].map((s) => (
                      <button
                        key={s}
                        onClick={() => setSize(s)}
                        className="flex-1 py-2.5 rounded-lg text-xs font-bold border-2 transition-all min-w-[32px]"
                        style={{ backgroundColor: size === s ? T : "transparent", color: size === s ? LINEN : COFFEE, borderColor: size === s ? T : MUTED, ...ff }}
                      >{s}</button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Condition */}
              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="text-xs font-bold" style={{ color: COFFEE, ...ff }}>Độ mới (%)</label>
                  <span className="text-sm font-bold" style={{ color: T, ...ff }}>
                    {condition}% — <span style={{ ...serif }}>{condLabel}</span>
                  </span>
                </div>
                <input type="range" min={30} max={100} value={condition} onChange={(e) => setCondition(Number(e.target.value))}
                  className="w-full h-2.5 rounded-full cursor-pointer" style={{ accentColor: T }} />
                <div className="flex justify-between mt-1">
                  <span className="text-[10px]" style={{ color: COFFEE + "88", ...ff }}>30% Cũ</span>
                  <span className="text-[10px]" style={{ color: COFFEE + "88", ...ff }}>100% Mới nguyên</span>
                </div>
              </div>

              {/* Action buttons */}
              <div className="pt-2 flex gap-3">
                <button
                  onClick={() => go("account")}
                  className="flex-1 py-3.5 rounded-xl font-bold text-base shadow-md transition-all hover:opacity-90 active:scale-[0.98]"
                  style={{ backgroundColor: T, color: LINEN, ...ff }}
                >
                  Đăng bán ngay 🌿
                </button>
                <button
                  className="px-5 py-3.5 rounded-xl font-semibold text-sm border-2 transition-all hover:opacity-80"
                  style={{ border: `2px solid ${MUTED}`, color: COFFEE, ...ff }}
                >
                  Lưu nháp
                </button>
              </div>
              <p className="text-[10px] text-center" style={{ color: COFFEE, ...ff }}>
                Sản phẩm của bạn sẽ được duyệt trong vòng 2–4 giờ trước khi hiển thị
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── App Shell ──────────────────────────────────────────────────────────────────
export default function App() {
  const [screen, setScreen] = useState<Screen>("login");
  const [products, setProducts] = useState<Product[]>(ALL_PRODUCTS);

  const go = (s: Screen) => setScreen(s);

  const toggleLike = (id: number) =>
    setProducts((prev) => prev.map((p) => p.id === id ? { ...p, liked: !p.liked } : p));

  const cartCount = INIT_CART.flatMap((g) => g.items).filter((i) => i.checked).length;
  const showHeader = screen !== "login";

  return (
    <div className="min-w-[1440px]" style={{ backgroundColor: LINEN, ...ff }}>
      {screen === "login" ? (
        <LoginScreen onLogin={() => go("home")} />
      ) : (
        <>
          <Header screen={screen} go={go} cartCount={cartCount} />
          <main>
            {screen === "home" && <HomeScreen go={go} products={products} onLike={toggleLike} />}
            {screen === "search" && <SearchScreen products={products} onLike={toggleLike} />}
            {screen === "cart" && <CartScreen go={go} />}
            {screen === "chat" && <ChatScreen />}
            {screen === "account" && <AccountScreen go={go} onLogout={() => go("login")} />}
            {screen === "post" && <PostScreen go={go} />}
          </main>
          {screen !== "cart" && <Footer go={go} />}
        </>
      )}
    </div>
  );
}
